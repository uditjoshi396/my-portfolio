import { useState } from 'react'
import { Link } from 'react-router-dom'
import axios from 'axios'
import { ArrowLeft, KeyRound, Mail, UserRound } from 'lucide-react'

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api'

export default function AuthPanel({ mode, title, subtitle }) {
  const isRegister = mode === 'register'
  const [form, setForm] = useState({ name: '', email: '', password: '' })
  const [status, setStatus] = useState('')
  const [loading, setLoading] = useState(false)

  const updateField = (event) => {
    setForm((current) => ({ ...current, [event.target.name]: event.target.value }))
  }

  const handleSubmit = async (event) => {
    event.preventDefault()
    setLoading(true)
    setStatus('')

    try {
      const endpoint = isRegister ? '/auth/register' : '/auth/login'
      const payload = isRegister ? form : { email: form.email, password: form.password }
      const { data } = await axios.post(`${API_URL}${endpoint}`, payload)
      localStorage.setItem('udit_joshi_token', data.token)
      setStatus(isRegister ? `Account created. Demo OTP: ${data.demoEmailOtp}` : `Logged in as ${data.user.name}`)
    } catch (error) {
      setStatus(error.response?.data?.message || 'Request failed. Check backend connection.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <main className="auth-page">
      <section className="auth-shell">
        <Link className="back-link" to="/">
          <ArrowLeft size={18} />
          Home
        </Link>

        <div>
          <p className="eyebrow">UDIT JOSHI Auth</p>
          <h1>{title}</h1>
          <p>{subtitle}</p>
        </div>

        <form className="auth-form" onSubmit={handleSubmit}>
          {isRegister && (
            <label>
              <span>Name</span>
              <div className="input-wrap">
                <UserRound size={18} />
                <input name="name" value={form.name} onChange={updateField} placeholder="Udit Joshi" required />
              </div>
            </label>
          )}

          <label>
            <span>Email</span>
            <div className="input-wrap">
              <Mail size={18} />
              <input name="email" type="email" value={form.email} onChange={updateField} placeholder="udit@example.com" required />
            </div>
          </label>

          <label>
            <span>Password</span>
            <div className="input-wrap">
              <KeyRound size={18} />
              <input name="password" type="password" value={form.password} onChange={updateField} placeholder="Minimum 6 characters" required />
            </div>
          </label>

          <button className="primary-btn" disabled={loading}>
            {loading ? 'Please wait...' : isRegister ? 'Create Account' : 'Sign In'}
          </button>

          {status && <p className="form-status">{status}</p>}
        </form>

        <p className="switch-auth">
          {isRegister ? 'Already have an account?' : 'New here?'}
          <Link to={isRegister ? '/login' : '/register'}>{isRegister ? 'Sign in' : 'Create one'}</Link>
        </p>
      </section>
    </main>
  )
}
