import AuthPanel from '../components/AuthPanel'

export default function Login() {
  return (
    <AuthPanel
      mode="login"
      title="Welcome back"
      subtitle="Sign in with JWT auth, request OTP, or connect Google OAuth in production."
    />
  )
}
