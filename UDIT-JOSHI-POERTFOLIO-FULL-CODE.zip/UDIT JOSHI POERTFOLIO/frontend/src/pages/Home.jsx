import { useEffect, useMemo, useState } from 'react'
import { motion } from 'framer-motion'
import { Link } from 'react-router-dom'
import axios from 'axios'
import {
  Activity,
  BadgeCheck,
  BookOpen,
  Boxes,
  BriefcaseBusiness,
  Cloud,
  Database,
  Download,
  ExternalLink,
  Facebook,
  GraduationCap,
  Github,
  Instagram,
  Linkedin,
  Layers3,
  LockKeyhole,
  Mail,
  MapPin,
  Moon,
  Phone,
  Rocket,
  Search,
  Send,
  ShieldCheck,
  Sun,
  Trophy,
  Twitter,
  UploadCloud
} from 'lucide-react'

const productionFeatures = [
  { icon: LockKeyhole, label: 'Role Based JWT Authentication' },
  { icon: BadgeCheck, label: 'Email Verification + OTP Login' },
  { icon: UploadCloud, label: 'Cloudinary Image Uploads' },
  { icon: Search, label: 'Search, Filter, Pagination' },
  { icon: ShieldCheck, label: 'Helmet Security + Rate Limiting' },
  { icon: Activity, label: 'Socket.io Realtime Events' },
  { icon: Database, label: 'MongoDB Atlas Ready' },
  { icon: Boxes, label: 'Docker, CI/CD, Kubernetes Notes' }
]

const projects = [
  {
    title: 'Full Stack E-Commerce Platform',
    type: 'Full Stack',
    summary: 'JWT auth, admin dashboard, product management, cart, wishlist, payments, orders, search filters, and Cloudinary uploads.',
    stack: ['React', 'Redux Toolkit', 'Node', 'Express', 'MongoDB'],
    liveUrl: 'https://udit-portfolio.vercel.app',
    githubUrl: 'https://github.com/'
  },
  {
    title: 'Job Portal Application',
    type: 'Full Stack',
    summary: 'Recruiter dashboard, candidate dashboard, resume upload, job apply system, profile management, and admin panel.',
    stack: ['React', 'Express', 'MongoDB', 'JWT', 'Multer'],
    liveUrl: 'https://udit-portfolio.vercel.app',
    githubUrl: 'https://github.com/'
  },
  {
    title: 'Real-Time Chat Application',
    type: 'Realtime',
    summary: 'Socket.io messaging, online status, notifications, group chat, typing indicators, and authenticated conversations.',
    stack: ['React', 'Socket.io', 'Node', 'Express', 'MongoDB'],
    liveUrl: 'https://udit-portfolio.vercel.app',
    githubUrl: 'https://github.com/'
  },
  {
    title: 'Full Stack Blog Platform',
    type: 'Content',
    summary: 'Rich text editor, authentication, comments, categories, CRUD operations, image uploads, and clean database design.',
    stack: ['React', 'REST APIs', 'MongoDB', 'Cloudinary'],
    liveUrl: 'https://udit-portfolio.vercel.app',
    githubUrl: 'https://github.com/'
  },
  {
    title: 'Task Management System',
    type: 'Productivity',
    summary: 'Drag and drop tasks, team collaboration, task statuses, dashboard analytics, authentication, and complex UI state.',
    stack: ['React', 'Redux Toolkit', 'Node', 'MongoDB'],
    liveUrl: 'https://udit-portfolio.vercel.app',
    githubUrl: 'https://github.com/'
  }
]

const stack = ['Vercel', 'Render/Railway', 'MongoDB Atlas', 'Cloudinary', 'GitHub Actions', 'Sentry']
const skillGroups = [
  { title: 'Frontend', level: 88, items: ['HTML5', 'CSS3', 'JavaScript', 'React.js', 'Redux Toolkit', 'Tailwind CSS', 'Bootstrap'] },
  { title: 'Backend', level: 82, items: ['Node.js', 'Express.js', 'REST APIs', 'JWT Authentication', 'Socket.io'] },
  { title: 'Database', level: 78, items: ['MongoDB', 'MySQL', 'Mongoose', 'Schema Design'] },
  { title: 'Languages', level: 84, items: ['Java', 'JavaScript'] },
  { title: 'Tools', level: 86, items: ['Git', 'GitHub', 'Postman', 'VS Code', 'Docker'] },
  { title: 'Deployment', level: 80, items: ['Vercel', 'Render', 'MongoDB Atlas', 'GitHub Actions'] }
]

const education = [
  {
    degree: 'Bachelor of Computer Applications',
    institute: 'Full Stack Web Development Focus',
    period: '2023 - Present',
    details: 'Building strong foundations in programming, databases, web application development, and deployment.'
  },
  {
    degree: 'MERN Stack Development',
    institute: 'Self-led Project Based Learning',
    period: '2024 - Present',
    details: 'Created production-style projects with authentication, APIs, uploads, realtime features, and CI/CD.'
  }
]

const experience = [
  {
    role: 'Full Stack Developer',
    company: 'Personal Production Projects',
    period: '2024 - Present',
    details: 'Built MERN applications with reusable React components, secure Express APIs, MongoDB schemas, and deployment-ready structure.'
  },
  {
    role: 'Frontend Developer',
    company: 'Portfolio and UI Projects',
    period: '2023 - Present',
    details: 'Designed responsive interfaces with clean layouts, loading states, error handling, and recruiter-friendly project presentation.'
  }
]

const contactLinks = [
  { icon: Mail, label: 'Email', value: 'uditjoshi@example.com', href: 'mailto:uditjoshi@example.com' },
  { icon: Phone, label: 'Phone', value: '+91 98765 43210', href: 'tel:+919876543210' },
  { icon: MapPin, label: 'Location', value: 'India', href: 'https://www.google.com/maps/place/India' },
  { icon: Github, label: 'GitHub', value: 'github.com/uditjoshi', href: 'https://github.com/' },
  { icon: Linkedin, label: 'LinkedIn', value: 'linkedin.com/in/uditjoshi', href: 'https://www.linkedin.com/in/uditjoshi/' },
  { icon: Facebook, label: 'Facebook', value: 'facebook.com/uditjoshi', href: 'https://www.facebook.com/uditjoshi' },
  { icon: Instagram, label: 'Instagram', value: 'instagram.com/uditjoshi', href: 'https://www.instagram.com/uditjoshi/' },
  { icon: Twitter, label: 'X / Twitter', value: 'x.com/uditjoshi', href: 'https://x.com/uditjoshi' }
]
const codingProfiles = [
  { label: 'LeetCode', value: 'Problem solving practice', href: 'https://leetcode.com/' },
  { label: 'HackerRank', value: 'Java and DSA basics', href: 'https://www.hackerrank.com/' },
  { label: 'GitHub Activity', value: 'Pinned real-world repositories', href: 'https://github.com/' }
]
const roadmap = [
  'Create polished portfolio UI',
  'Build authentication system',
  'Build e-commerce backend',
  'Connect Redux frontend',
  'Deploy on Vercel and Render',
  'Optimize resume and LinkedIn SEO'
]
const resources = ['React Documentation', 'Tailwind Documentation', 'Node.js Documentation', 'Express Documentation', 'MongoDB University', 'Vercel Docs', 'Render Docs']
const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api'

export default function Home() {
  const [remoteProjects, setRemoteProjects] = useState([])
  const [search, setSearch] = useState('')
  const [projectFilter, setProjectFilter] = useState('All')
  const [status, setStatus] = useState('Loading projects...')
  const [darkMode, setDarkMode] = useState(false)
  const [scrollProgress, setScrollProgress] = useState(0)
  const [toast, setToast] = useState('')
  const [contactForm, setContactForm] = useState({ name: '', email: '', message: '' })

  const visibleProjects = useMemo(() => {
    const source = remoteProjects.length
      ? remoteProjects.map((project) => ({
        title: project.title,
        type: project.category,
        summary: project.description,
        stack: project.techStack || [],
        liveUrl: project.liveUrl,
        githubUrl: project.githubUrl
      }))
      : projects

    return source.filter((project) => projectFilter === 'All' || project.type === projectFilter)
  }, [remoteProjects, projectFilter])

  const projectTypes = useMemo(() => {
    return ['All', 'Full Stack', 'Frontend', 'Backend', 'Realtime', 'Content', 'Productivity']
  }, [])

  useEffect(() => {
    const loadProjects = async () => {
      try {
        const query = search ? `?search=${encodeURIComponent(search)}` : ''
        const { data } = await axios.get(`${API_URL}/projects${query}`)
        setRemoteProjects(data.items || [])
        setStatus(data.items?.length ? `${data.items.length} project loaded from API` : 'No API projects yet. Run npm run seed in backend.')
      } catch (error) {
        setStatus('Using local project cards until the backend is available.')
      }
    }

    const timer = setTimeout(loadProjects, 250)
    return () => clearTimeout(timer)
  }, [search])

  useEffect(() => {
    document.body.dataset.theme = darkMode ? 'dark' : 'light'
  }, [darkMode])

  useEffect(() => {
    const updateProgress = () => {
      const total = document.documentElement.scrollHeight - window.innerHeight
      setScrollProgress(total > 0 ? Math.min((window.scrollY / total) * 100, 100) : 0)
    }

    updateProgress()
    window.addEventListener('scroll', updateProgress)
    return () => window.removeEventListener('scroll', updateProgress)
  }, [])

  const submitContact = (event) => {
    event.preventDefault()
    setToast(`Thanks ${contactForm.name || 'there'}, your message is ready to send.`)
    setContactForm({ name: '', email: '', message: '' })
    setTimeout(() => setToast(''), 3200)
  }

  return (
    <main className="site-shell">
      <div className="scroll-progress" style={{ width: `${scrollProgress}%` }} />
      {toast && <div className="toast-message">{toast}</div>}
      <nav className="topbar">
        <Link className="brand" to="/">
          <span className="brand-mark">UJ</span>
          Udit Joshi
        </Link>
        <div className="nav-actions">
          <a href="#projects">Projects</a>
          <a href="#skills">Skills</a>
          <a href="#education">Education</a>
          <a href="#experience">Experience</a>
          <a href="#contact">Contact</a>
          <a href="#stack">Stack</a>
          <Link to="/admin">Admin</Link>
          <button className="icon-toggle" onClick={() => setDarkMode((current) => !current)} aria-label="Toggle dark mode">
            {darkMode ? <Sun size={18} /> : <Moon size={18} />}
          </button>
          <Link className="nav-btn" to="/login">Login</Link>
        </div>
      </nav>

      <section className="hero-grid">
        <motion.div
          className="hero-copy"
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.55 }}
        >
          <div className="hero-kicker">
            <p className="eyebrow">Full Stack Developer Portfolio</p>
            <span className="availability-dot">Open to work</span>
          </div>
          <h1>Udit Joshi Full Stack Developer building scalable web applications.</h1>
          <p className="hero-text">
            Building responsive applications using React.js, Node.js, Express.js, MongoDB,
            JavaScript, and Java with production-ready authentication, APIs, and deployments.
          </p>
          <div className="hero-actions">
            <a className="primary-btn" href="/resume.txt" download>
              <Download size={18} />
              Resume
            </a>
            <a className="primary-btn" href="#projects">
              <Rocket size={18} />
              View Projects
            </a>
            <a className="secondary-btn" href="https://github.com/" target="_blank" rel="noreferrer">
              <Github size={18} />
              GitHub
            </a>
            <a className="secondary-btn" href="https://www.linkedin.com/in/uditjoshi/" target="_blank" rel="noreferrer">
              <Linkedin size={18} />
              LinkedIn
            </a>
            <a className="secondary-btn" href="#contact">
              <Mail size={18} />
              Contact
            </a>
          </div>
          <div className="hero-stats" aria-label="Portfolio highlights">
            <div>
              <strong>15+</strong>
              <span>Core features</span>
            </div>
            <div>
              <strong>3</strong>
              <span>Featured projects</span>
            </div>
            <div>
              <strong>MERN</strong>
              <span>Primary stack</span>
            </div>
          </div>
        </motion.div>

        <motion.div
          className="signal-panel"
          initial={{ opacity: 0, scale: 0.96 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.55, delay: 0.12 }}
        >
          <div className="avatar-card">
            <img className="profile-photo" src="/profile-photo.jpg" alt="Udit Joshi profile" />
            <div>
              <span>Portfolio System</span>
              <strong>Udit Joshi</strong>
            </div>
          </div>
          <div className="panel-header">
            <span>Production Readiness</span>
            <strong>92%</strong>
          </div>
          <div className="metric-row">
            <span>Authentication</span>
            <b>JWT + OTP</b>
          </div>
          <div className="metric-row">
            <span>Deployment</span>
            <b>Docker + CI</b>
          </div>
          <div className="metric-row">
            <span>API Quality</span>
            <b>Secure REST</b>
          </div>
          <div className="pipeline">
            <Cloud size={18} />
            {'Vercel -> Render -> MongoDB Atlas -> Cloudinary'}
          </div>
        </motion.div>
      </section>

      <section className="feature-grid" aria-label="Production features">
        {productionFeatures.map((feature) => {
          const Icon = feature.icon
          return (
            <article className="feature-card" key={feature.label}>
              <Icon size={22} />
              <span>{feature.label}</span>
            </article>
          )
        })}
      </section>

      <section className="section-block about-section" id="about">
        <div>
          <p className="eyebrow">About</p>
          <h2>I build scalable and user-friendly web applications.</h2>
        </div>
        <p>
          I am a Full Stack Developer focused on building scalable and user-friendly web applications.
          I work with modern technologies including React.js, Node.js, Express.js, MongoDB,
          JavaScript, and Java. I enjoy solving real-world problems and continuously improving
          my development skills.
        </p>
      </section>

      <section className="section-block profile-grid" id="skills">
        <div className="section-heading">
          <p className="eyebrow">Skills</p>
          <h2>Practical full stack skills for real projects.</h2>
        </div>
        <div className="skills-panel">
          <div className="skills-icon">
            <Layers3 size={28} />
          </div>
          <div className="skill-groups">
            {skillGroups.map((group) => (
              <article className="skill-group" key={group.title}>
                <div className="skill-group-head">
                  <strong>{group.title}</strong>
                  <span>{group.level}%</span>
                </div>
                <div className="skill-bar">
                  <span style={{ width: `${group.level}%` }} />
                </div>
                <div className="skill-list">
                  {group.items.map((skill) => <span key={skill}>{skill}</span>)}
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="section-block two-column-section">
        <div id="education">
          <div className="section-heading">
            <p className="eyebrow">Education</p>
            <h2>Learning path</h2>
          </div>
          <div className="timeline-list">
            {education.map((item) => (
              <article className="timeline-card" key={item.degree}>
                <GraduationCap size={22} />
                <div>
                  <span>{item.period}</span>
                  <h3>{item.degree}</h3>
                  <strong>{item.institute}</strong>
                  <p>{item.details}</p>
                </div>
              </article>
            ))}
          </div>
        </div>

        <div id="experience">
          <div className="section-heading">
            <p className="eyebrow">Experience</p>
            <h2>Hands-on work</h2>
          </div>
          <div className="timeline-list">
            {experience.map((item) => (
              <article className="timeline-card" key={item.role}>
                <BriefcaseBusiness size={22} />
                <div>
                  <span>{item.period}</span>
                  <h3>{item.role}</h3>
                  <strong>{item.company}</strong>
                  <p>{item.details}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="section-block" id="projects">
        <div className="section-heading">
          <p className="eyebrow">Selected Work</p>
          <h2>Projects shaped for job selection</h2>
          <div className="project-tools">
            <input
              value={search}
              onChange={(event) => setSearch(event.target.value)}
              placeholder="Search projects"
            />
            <div className="filter-tabs">
              {projectTypes.map((type) => (
                <button className={projectFilter === type ? 'active' : ''} onClick={() => setProjectFilter(type)} key={type}>
                  {type}
                </button>
              ))}
            </div>
            <span>{status}</span>
          </div>
        </div>
        <div className="project-grid">
          {visibleProjects.map((project) => (
            <article className="project-card" key={project.title}>
              <span>{project.type}</span>
              <h3>{project.title}</h3>
              <p>{project.summary}</p>
              <div className="chips">
                {project.stack.map((item) => <b key={item}>{item}</b>)}
              </div>
              <div className="project-links">
                <a href={project.liveUrl || 'https://udit-portfolio.vercel.app'} target="_blank" rel="noreferrer">
                  <ExternalLink size={16} />
                  Live Demo
                </a>
                <a href={project.githubUrl || 'https://github.com/'} target="_blank" rel="noreferrer">
                  <Github size={16} />
                  Source Code
                </a>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className="section-block profile-grid" id="profiles">
        <div className="section-heading">
          <p className="eyebrow">Coding Profiles</p>
          <h2>GitHub activity and practice platforms.</h2>
        </div>
        <div className="profile-link-grid">
          {codingProfiles.map((profile) => (
            <a className="profile-link-card" href={profile.href} target="_blank" rel="noreferrer" key={profile.label}>
              <Trophy size={22} />
              <strong>{profile.label}</strong>
              <span>{profile.value}</span>
              <ExternalLink size={16} />
            </a>
          ))}
        </div>
      </section>

      <section className="section-block stack-band" id="stack">
        <div>
          <p className="eyebrow">Best Deployment Stack</p>
          <h2>Simple, affordable, fresher-friendly deployment path.</h2>
        </div>
        <div className="stack-list">
          {stack.map((item) => <span key={item}>{item}</span>)}
        </div>
      </section>

      <section className="section-block two-column-section">
        <div>
          <div className="section-heading">
            <p className="eyebrow">Action Plan</p>
            <h2>Six-week portfolio roadmap</h2>
          </div>
          <div className="roadmap-list">
            {roadmap.map((item, index) => (
              <article key={item}>
                <span>Week {index + 1}</span>
                <strong>{item}</strong>
              </article>
            ))}
          </div>
        </div>
        <div>
          <div className="section-heading">
            <p className="eyebrow">Resources</p>
            <h2>Learning sources to keep improving.</h2>
          </div>
          <div className="resource-list">
            {resources.map((item) => (
              <span key={item}><BookOpen size={16} />{item}</span>
            ))}
          </div>
        </div>
      </section>

      <section className="ats-box">
        <p className="eyebrow">ATS-ready Description</p>
        <p>
          Built a production-ready MERN stack application with JWT authentication,
          Socket.io realtime communication, Cloudinary uploads, Docker containerization,
          GitHub Actions CI/CD pipeline, and responsive modern UI.
        </p>
      </section>

      <section className="section-block contact-band" id="contact">
        <div>
          <p className="eyebrow">Contact</p>
          <h2>Available for internships, fresher roles, and full stack projects.</h2>
        </div>
        <div className="contact-grid">
          {contactLinks.map((item) => {
            const Icon = item.icon
            return (
              <a className="contact-card" href={item.href} target={item.href.startsWith('http') ? '_blank' : undefined} rel="noreferrer" key={item.label}>
                <Icon size={22} />
                <span>{item.label}</span>
                <strong>{item.value}</strong>
              </a>
            )
          })}
        </div>
        <form className="contact-form" onSubmit={submitContact}>
          <p className="eyebrow">Message</p>
          <input value={contactForm.name} onChange={(event) => setContactForm((current) => ({ ...current, name: event.target.value }))} placeholder="Your name" required />
          <input value={contactForm.email} onChange={(event) => setContactForm((current) => ({ ...current, email: event.target.value }))} type="email" placeholder="Your email" required />
          <textarea value={contactForm.message} onChange={(event) => setContactForm((current) => ({ ...current, message: event.target.value }))} placeholder="Project, internship, or hiring message" required />
          <button className="primary-btn">
            <Send size={18} />
            Send Message
          </button>
        </form>
      </section>
    </main>
  )
}
