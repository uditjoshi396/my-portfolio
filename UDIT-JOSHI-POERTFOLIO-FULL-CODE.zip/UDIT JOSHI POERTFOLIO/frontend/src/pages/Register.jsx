import AuthPanel from '../components/AuthPanel'

export default function Register() {
  return (
    <AuthPanel
      mode="register"
      title="Create account"
      subtitle="Includes email verification OTP, protected APIs, and role-ready user records."
    />
  )
}
