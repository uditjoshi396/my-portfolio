import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import axios from 'axios'
import { ArrowLeft, CreditCard, Plus, ShieldCheck, UploadCloud } from 'lucide-react'

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api'

const emptyProject = {
  title: '',
  description: '',
  category: 'Full Stack',
  techStack: 'React, Node.js, MongoDB',
  githubUrl: '',
  liveUrl: '',
  featured: true
}

export default function Admin() {
  const [token, setToken] = useState(localStorage.getItem('udit_joshi_token') || '')
  const [project, setProject] = useState(emptyProject)
  const [projects, setProjects] = useState([])
  const [status, setStatus] = useState('Login as admin, then create projects and test protected APIs.')

  const headers = token ? { Authorization: `Bearer ${token}` } : {}

  const loadProjects = async () => {
    const { data } = await axios.get(`${API_URL}/projects`)
    setProjects(data.items || [])
  }

  useEffect(() => {
    loadProjects().catch(() => setStatus('Backend not reachable yet. Start backend on port 5000.'))
  }, [])

  const updateField = (event) => {
    const { name, value, type, checked } = event.target
    setProject((current) => ({ ...current, [name]: type === 'checkbox' ? checked : value }))
  }

  const saveProject = async (event) => {
    event.preventDefault()

    try {
      const payload = {
        ...project,
        techStack: project.techStack.split(',').map((item) => item.trim()).filter(Boolean)
      }
      await axios.post(`${API_URL}/projects`, payload, { headers })
      setProject(emptyProject)
      setStatus('Project created successfully.')
      await loadProjects()
    } catch (error) {
      setStatus(error.response?.data?.message || 'Create failed. Use an admin token.')
    }
  }

  const startCheckout = async () => {
    try {
      const { data } = await axios.post(`${API_URL}/payments/checkout-session`, {}, { headers })
      window.location.href = data.url
    } catch (error) {
      setStatus(error.response?.data?.message || 'Stripe checkout is not configured yet.')
    }
  }

  const uploadDemo = async (event) => {
    const file = event.target.files?.[0]

    if (!file) {
      return
    }

    const formData = new FormData()
    formData.append('file', file)

    try {
      await axios.post(`${API_URL}/uploads/file`, formData, { headers })
      setStatus(`Uploaded ${file.name} to protected file endpoint.`)
    } catch (error) {
      setStatus(error.response?.data?.message || 'Upload failed. Use a valid token.')
    }
  }

  return (
    <main className="admin-page">
      <section className="admin-shell">
        <div className="admin-top">
          <Link className="back-link" to="/">
            <ArrowLeft size={18} />
            Home
          </Link>
          <div className="admin-badge">
            <ShieldCheck size={18} />
            Admin Dashboard
          </div>
        </div>

        <div className="admin-hero">
          <div>
            <p className="eyebrow">Control Room</p>
            <h1>Manage portfolio projects and protected production APIs.</h1>
            <p>{status}</p>
          </div>
        </div>

        <div className="admin-grid">
          <form className="admin-card admin-form" onSubmit={saveProject}>
            <h2>Create Project</h2>
            <input
              value={token}
              onChange={(event) => {
                setToken(event.target.value)
                localStorage.setItem('udit_joshi_token', event.target.value)
              }}
              placeholder="Paste admin JWT token"
            />
            <input name="title" value={project.title} onChange={updateField} placeholder="Project title" required />
            <textarea name="description" value={project.description} onChange={updateField} placeholder="Project description" required />
            <input name="category" value={project.category} onChange={updateField} placeholder="Category" />
            <input name="techStack" value={project.techStack} onChange={updateField} placeholder="React, Node.js, MongoDB" />
            <input name="githubUrl" value={project.githubUrl} onChange={updateField} placeholder="GitHub URL" />
            <input name="liveUrl" value={project.liveUrl} onChange={updateField} placeholder="Live URL" />
            <label className="check-row">
              <input name="featured" type="checkbox" checked={project.featured} onChange={updateField} />
              Featured project
            </label>
            <button className="primary-btn">
              <Plus size={18} />
              Save Project
            </button>
          </form>

          <section className="admin-card action-panel">
            <h2>Production Actions</h2>
            <button className="secondary-btn" onClick={startCheckout}>
              <CreditCard size={18} />
              Test Stripe Checkout
            </button>
            <label className="upload-btn">
              <UploadCloud size={18} />
              Upload Protected File
              <input type="file" onChange={uploadDemo} />
            </label>
            <div className="mini-list">
              {projects.map((item) => (
                <article key={item._id || item.title}>
                  <strong>{item.title}</strong>
                  <span>{item.category}</span>
                </article>
              ))}
            </div>
          </section>
        </div>
      </section>
    </main>
  )
}
