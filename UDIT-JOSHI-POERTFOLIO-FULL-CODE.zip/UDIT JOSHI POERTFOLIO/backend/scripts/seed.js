const mongoose = require('mongoose')
const bcrypt = require('bcryptjs')
require('dotenv').config()

const User = require('../models/User')
const Project = require('../models/Project')

const projects = [
  {
    title: 'Full Stack E-Commerce Platform',
    description: 'JWT authentication, admin dashboard, product management, cart, wishlist, payment gateway, order management, search filters, responsive UI, and image upload.',
    category: 'Full Stack',
    techStack: ['React', 'Redux Toolkit', 'Node.js', 'Express', 'MongoDB'],
    featured: true,
    githubUrl: 'https://github.com/',
    liveUrl: 'https://vercel.com/'
  },
  {
    title: 'Job Portal Application',
    description: 'Recruiter dashboard, candidate dashboard, resume upload, job apply system, authentication, profile management, and admin panel.',
    category: 'Full Stack',
    techStack: ['React', 'Express', 'MongoDB', 'JWT', 'Multer'],
    featured: true,
    githubUrl: 'https://github.com/'
  },
  {
    title: 'Real-Time Chat Application',
    description: 'Real-time messaging, online status, notifications, Socket.io integration, group chat, typing indicator, and authentication.',
    category: 'Realtime',
    techStack: ['React', 'Socket.io', 'Node.js', 'Express', 'MongoDB'],
    featured: true,
    githubUrl: 'https://github.com/'
  },
  {
    title: 'Full Stack Blog Platform',
    description: 'Rich text editor, authentication, comments, CRUD operations, image upload, categories, API development, and database design.',
    category: 'Content',
    techStack: ['React', 'REST APIs', 'MongoDB', 'Cloudinary'],
    featured: false,
    githubUrl: 'https://github.com/'
  },
  {
    title: 'Task Management System',
    description: 'Drag and drop tasks, team collaboration, task status, dashboard analytics, authentication, complex UI, and state management.',
    category: 'Productivity',
    techStack: ['React', 'Redux Toolkit', 'Node.js', 'MongoDB'],
    featured: false,
    liveUrl: 'https://vercel.com/'
  }
]

const run = async () => {
  const dbName = process.env.DB_NAME || 'udit_joshi'
  await mongoose.connect(process.env.MONGO_URI, { dbName })

  const password = await bcrypt.hash('Admin@123', 10)
  const admin = await User.findOneAndUpdate(
    { email: 'admin@uditjoshi.com' },
    {
      name: 'Udit Joshi',
      email: 'admin@uditjoshi.com',
      password,
      role: 'admin',
      isEmailVerified: true
    },
    { upsert: true, new: true, setDefaultsOnInsert: true }
  )

  await Project.deleteMany({})
  await Project.insertMany(projects.map((project) => ({ ...project, owner: admin._id })))

  console.log(`Seed complete for MongoDB database: ${dbName}`)
  console.log('Admin email: admin@uditjoshi.com')
  console.log('Admin password: Admin@123')
  await mongoose.disconnect()
}

run().catch(async (error) => {
  console.error(error)
  await mongoose.disconnect()
  process.exit(1)
})
