const express = require('express')
const mongoose = require('mongoose')
const cors = require('cors')
const helmet = require('helmet')
const rateLimit = require('express-rate-limit')
const http = require('http')
const { Server } = require('socket.io')
require('dotenv').config()

const authRoutes = require('./routes/authRoutes')
const projectRoutes = require('./routes/projectRoutes')
const uploadRoutes = require('./routes/uploadRoutes')
const paymentRoutes = require('./routes/paymentRoutes')
const { notFound, errorHandler } = require('./middleware/errorMiddleware')
const { connectCache } = require('./utils/cache')

const app = express()
const allowedOrigins = (process.env.CLIENT_URL || 'http://localhost:5173')
  .split(',')
  .map((origin) => origin.trim())
  .filter(Boolean)

const server = http.createServer(app)
const io = new Server(server, {
  cors: {
    origin: allowedOrigins,
    methods: ['GET', 'POST']
  }
})

app.use(helmet())
app.use(cors({
  origin: allowedOrigins,
  credentials: true
}))
app.use(express.json())
app.use(rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 120,
  standardHeaders: true,
  legacyHeaders: false
}))

io.on('connection', (socket) => {
  socket.emit('server:ready', { message: 'Realtime channel connected' })

  socket.on('chat:message', (payload) => {
    io.emit('chat:message', {
      ...payload,
      createdAt: new Date().toISOString()
    })
  })
})

app.set('io', io)

app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    service: 'UDIT JOSHI API',
    uptime: process.uptime()
  })
})
app.use('/api/auth', authRoutes)
app.use('/api/projects', projectRoutes)
app.use('/api/uploads', uploadRoutes)
app.use('/api/payments', paymentRoutes)

app.use(notFound)
app.use(errorHandler)

const PORT = process.env.PORT || 5000

mongoose.connect(process.env.MONGO_URI, {
  dbName: process.env.DB_NAME || 'udit_joshi'
})
  .then(() => {
    console.log(`MongoDB Connected: ${process.env.DB_NAME || 'udit_joshi'}`)
    connectCache().catch((error) => {
      console.warn('Redis cache skipped:', error.message)
    })
    server.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`)
    })
  })
  .catch((error) => {
    console.error('MongoDB connection failed:', error.message)
    process.exit(1)
  })
