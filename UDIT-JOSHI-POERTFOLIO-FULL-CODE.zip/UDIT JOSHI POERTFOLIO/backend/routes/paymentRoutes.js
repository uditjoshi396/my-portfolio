const express = require('express')
const Stripe = require('stripe')
const { protect } = require('../middleware/authMiddleware')

const router = express.Router()

router.post('/checkout-session', protect, async (req, res) => {
  if (!process.env.STRIPE_SECRET_KEY) {
    return res.status(503).json({
      message: 'Stripe is not configured',
      requiredEnv: ['STRIPE_SECRET_KEY']
    })
  }

  const stripe = new Stripe(process.env.STRIPE_SECRET_KEY)
  const { name = 'Portfolio Service', amount = 49900 } = req.body

  const session = await stripe.checkout.sessions.create({
    mode: 'payment',
    payment_method_types: ['card'],
    line_items: [
      {
        quantity: 1,
        price_data: {
          currency: 'inr',
          unit_amount: amount,
          product_data: { name }
        }
      }
    ],
    success_url: `${process.env.CLIENT_URL || 'http://localhost:5173'}/admin?payment=success`,
    cancel_url: `${process.env.CLIENT_URL || 'http://localhost:5173'}/admin?payment=cancelled`
  })

  res.json({ url: session.url })
})

module.exports = router
