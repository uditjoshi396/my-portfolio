const express = require('express')
const Project = require('../models/Project')
const { protect, authorize } = require('../middleware/authMiddleware')
const { getCache, setCache, clearCache } = require('../utils/cache')

const router = express.Router()

router.get('/', async (req, res) => {
  const cacheKey = `projects:${JSON.stringify(req.query)}`
  const cached = await getCache(cacheKey)

  if (cached) {
    return res.json({ ...cached, cached: true })
  }

  const page = Math.max(Number(req.query.page) || 1, 1)
  const limit = Math.min(Math.max(Number(req.query.limit) || 6, 1), 24)
  const skip = (page - 1) * limit
  const { search, category, featured } = req.query

  const filter = {}

  if (search) {
    filter.$text = { $search: search }
  }

  if (category) {
    filter.category = category
  }

  if (featured !== undefined) {
    filter.featured = featured === 'true'
  }

  const [items, total] = await Promise.all([
    Project.find(filter)
      .sort({ featured: -1, createdAt: -1 })
      .skip(skip)
      .limit(limit),
    Project.countDocuments(filter)
  ])

  const response = {
    items,
    pagination: {
      page,
      limit,
      total,
      pages: Math.ceil(total / limit) || 1
    }
  }

  await setCache(cacheKey, response, 90)
  res.json(response)
})

router.get('/:id', async (req, res) => {
  const project = await Project.findById(req.params.id)

  if (!project) {
    return res.status(404).json({ message: 'Project not found' })
  }

  res.json(project)
})

router.post('/', protect, authorize('admin'), async (req, res) => {
  const project = await Project.create({
    ...req.body,
    owner: req.user._id
  })

  req.app.get('io').emit('project:created', project)
  await clearCache('projects:*')
  res.status(201).json(project)
})

router.put('/:id', protect, authorize('admin'), async (req, res) => {
  const project = await Project.findByIdAndUpdate(req.params.id, req.body, {
    new: true,
    runValidators: true
  })

  if (!project) {
    return res.status(404).json({ message: 'Project not found' })
  }

  await clearCache('projects:*')
  res.json(project)
})

router.delete('/:id', protect, authorize('admin'), async (req, res) => {
  const project = await Project.findByIdAndDelete(req.params.id)

  if (!project) {
    return res.status(404).json({ message: 'Project not found' })
  }

  await clearCache('projects:*')
  res.json({ message: 'Project deleted successfully' })
})

module.exports = router
