const express = require('express')
const bcrypt = require('bcryptjs')
const User = require('../models/User')
const { protect } = require('../middleware/authMiddleware')
const { signToken, createOtp, publicUser } = require('../utils/auth')

const router = express.Router()

router.post('/register', async (req, res) => {
  const { name, email, password } = req.body

  if (!name || !email || !password) {
    return res.status(400).json({ message: 'Name, email and password are required' })
  }

  const existingUser = await User.findOne({ email })

  if (existingUser) {
    return res.status(409).json({ message: 'Email already registered' })
  }

  const hashedPassword = await bcrypt.hash(password, 10)
  const otp = createOtp()

  const user = await User.create({
    name,
    email,
    password: hashedPassword,
    emailVerificationOtp: otp,
    emailVerificationExpires: Date.now() + 10 * 60 * 1000
  })

  res.status(201).json({
    user: publicUser(user),
    token: signToken(user),
    demoEmailOtp: otp
  })
})

router.post('/login', async (req, res) => {
  const { email, password } = req.body

  const user = await User.findOne({ email }).select('+password')

  if (!user) {
    return res.status(401).json({ message: 'Invalid email or password' })
  }

  const isMatch = await bcrypt.compare(password, user.password)

  if (!isMatch) {
    return res.status(401).json({ message: 'Invalid email or password' })
  }

  res.json({
    user: publicUser(user),
    token: signToken(user)
  })
})

router.get('/me', protect, async (req, res) => {
  res.json({ user: publicUser(req.user) })
})

router.post('/verify-email', protect, async (req, res) => {
  const { otp } = req.body
  const user = await User.findById(req.user._id)

  if (
    !otp ||
    user.emailVerificationOtp !== otp ||
    !user.emailVerificationExpires ||
    user.emailVerificationExpires < Date.now()
  ) {
    return res.status(400).json({ message: 'Invalid or expired OTP' })
  }

  user.isEmailVerified = true
  user.emailVerificationOtp = undefined
  user.emailVerificationExpires = undefined
  await user.save()

  res.json({ message: 'Email verified successfully', user: publicUser(user) })
})

router.post('/request-otp', async (req, res) => {
  const { email } = req.body
  const user = await User.findOne({ email })

  if (!user) {
    return res.status(404).json({ message: 'User not found' })
  }

  const otp = createOtp()
  user.loginOtp = otp
  user.loginOtpExpires = Date.now() + 5 * 60 * 1000
  await user.save()

  res.json({
    message: 'OTP generated. Connect an email/SMS provider before production.',
    demoLoginOtp: otp
  })
})

router.post('/verify-otp', async (req, res) => {
  const { email, otp } = req.body
  const user = await User.findOne({ email })

  if (
    !user ||
    user.loginOtp !== otp ||
    !user.loginOtpExpires ||
    user.loginOtpExpires < Date.now()
  ) {
    return res.status(400).json({ message: 'Invalid or expired OTP' })
  }

  user.loginOtp = undefined
  user.loginOtpExpires = undefined
  await user.save()

  res.json({
    user: publicUser(user),
    token: signToken(user)
  })
})

router.post('/forgot-password', async (req, res) => {
  const { email } = req.body
  const user = await User.findOne({ email })

  if (!user) {
    return res.status(404).json({ message: 'User not found' })
  }

  const otp = createOtp()
  user.passwordResetOtp = otp
  user.passwordResetExpires = Date.now() + 10 * 60 * 1000
  await user.save()

  res.json({
    message: 'Password reset OTP generated. Connect an email provider before production.',
    demoPasswordResetOtp: otp
  })
})

router.post('/reset-password', async (req, res) => {
  const { email, otp, password } = req.body
  const user = await User.findOne({ email }).select('+password')

  if (
    !user ||
    user.passwordResetOtp !== otp ||
    !user.passwordResetExpires ||
    user.passwordResetExpires < Date.now()
  ) {
    return res.status(400).json({ message: 'Invalid or expired reset OTP' })
  }

  user.password = await bcrypt.hash(password, 10)
  user.passwordResetOtp = undefined
  user.passwordResetExpires = undefined
  await user.save()

  res.json({ message: 'Password reset successfully' })
})

router.get('/google', (req, res) => {
  res.json({
    message: 'Google OAuth route placeholder',
    setup: 'Add Google client credentials and Passport strategy to enable OAuth login.'
  })
})

module.exports = router
