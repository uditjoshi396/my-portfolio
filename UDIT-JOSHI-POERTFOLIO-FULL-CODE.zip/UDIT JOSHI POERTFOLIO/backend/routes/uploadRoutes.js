const express = require('express')
const multer = require('multer')
const { v2: cloudinary } = require('cloudinary')
const { protect } = require('../middleware/authMiddleware')

const router = express.Router()
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 5 * 1024 * 1024 }
})

cloudinary.config({
  cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
  api_key: process.env.CLOUDINARY_API_KEY,
  api_secret: process.env.CLOUDINARY_API_SECRET
})

router.post('/file', protect, upload.single('file'), (req, res) => {
  if (!req.file) {
    return res.status(400).json({ message: 'No file uploaded' })
  }

  res.status(201).json({
    message: 'File received successfully',
    file: {
      originalName: req.file.originalname,
      mimeType: req.file.mimetype,
      size: req.file.size
    }
  })
})

router.post('/image', protect, upload.single('image'), async (req, res) => {
  if (!req.file) {
    return res.status(400).json({ message: 'No image uploaded' })
  }

  if (!process.env.CLOUDINARY_CLOUD_NAME) {
    return res.status(503).json({
      message: 'Cloudinary is not configured',
      requiredEnv: ['CLOUDINARY_CLOUD_NAME', 'CLOUDINARY_API_KEY', 'CLOUDINARY_API_SECRET']
    })
  }

  const dataUri = `data:${req.file.mimetype};base64,${req.file.buffer.toString('base64')}`
  const result = await cloudinary.uploader.upload(dataUri, {
    folder: 'udit-joshi'
  })

  res.status(201).json({
    publicId: result.public_id,
    url: result.secure_url
  })
})

module.exports = router
