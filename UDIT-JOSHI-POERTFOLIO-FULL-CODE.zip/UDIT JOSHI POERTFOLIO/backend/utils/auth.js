const jwt = require('jsonwebtoken')

const signToken = (user) => jwt.sign(
  { id: user._id, role: user.role },
  process.env.JWT_SECRET,
  { expiresIn: process.env.JWT_EXPIRES_IN || '7d' }
)

const createOtp = () => String(Math.floor(100000 + Math.random() * 900000))

const publicUser = (user) => ({
  id: user._id,
  name: user.name,
  email: user.email,
  role: user.role,
  avatar: user.avatar,
  isEmailVerified: user.isEmailVerified
})

module.exports = { signToken, createOtp, publicUser }
