const { createClient } = require('redis')

let client
let ready = false

const connectCache = async () => {
  if (!process.env.REDIS_URL || client) {
    return
  }

  client = createClient({ url: process.env.REDIS_URL })
  client.on('error', (error) => {
    ready = false
    console.warn('Redis cache unavailable:', error.message)
  })

  await client.connect()
  ready = true
  console.log('Redis cache connected')
}

const getCache = async (key) => {
  if (!ready) {
    return null
  }

  const value = await client.get(key)
  return value ? JSON.parse(value) : null
}

const setCache = async (key, value, ttlSeconds = 60) => {
  if (!ready) {
    return
  }

  await client.set(key, JSON.stringify(value), { EX: ttlSeconds })
}

const clearCache = async (pattern) => {
  if (!ready) {
    return
  }

  const keys = await client.keys(pattern)
  if (keys.length) {
    await client.del(keys)
  }
}

module.exports = { connectCache, getCache, setCache, clearCache }
