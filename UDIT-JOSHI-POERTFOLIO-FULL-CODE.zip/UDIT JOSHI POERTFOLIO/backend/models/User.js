const mongoose = require('mongoose')

const userSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
    trim: true
  },
  email: {
    type: String,
    required: true,
    unique: true,
    lowercase: true,
    trim: true
  },
  password: {
    type: String,
    required: true,
    minlength: 6,
    select: false
  },
  role: {
    type: String,
    enum: ['user', 'admin'],
    default: 'user'
  },
  avatar: {
    publicId: String,
    url: String
  },
  isEmailVerified: {
    type: Boolean,
    default: false
  },
  emailVerificationOtp: String,
  emailVerificationExpires: Date,
  passwordResetOtp: String,
  passwordResetExpires: Date,
  loginOtp: String,
  loginOtpExpires: Date,
  googleId: String
}, { timestamps: true })

module.exports = mongoose.model('User', userSchema)
