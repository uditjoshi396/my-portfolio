const mongoose = require('mongoose')

const projectSchema = new mongoose.Schema({
  title: {
    type: String,
    required: true,
    trim: true
  },
  description: {
    type: String,
    required: true
  },
  category: {
    type: String,
    default: 'Full Stack'
  },
  techStack: [{
    type: String,
    trim: true
  }],
  image: {
    publicId: String,
    url: String
  },
  githubUrl: String,
  liveUrl: String,
  featured: {
    type: Boolean,
    default: false
  },
  owner: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  }
}, { timestamps: true })

projectSchema.index({ title: 'text', description: 'text', category: 'text', techStack: 'text' })

module.exports = mongoose.model('Project', projectSchema)
