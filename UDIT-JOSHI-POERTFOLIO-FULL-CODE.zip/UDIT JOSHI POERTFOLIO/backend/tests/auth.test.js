const test = require('node:test')
const assert = require('node:assert/strict')
const { createOtp, publicUser } = require('../utils/auth')

test('createOtp returns a six digit code', () => {
  const otp = createOtp()

  assert.match(otp, /^\d{6}$/)
})

test('publicUser removes sensitive fields', () => {
  const user = {
    _id: 'user-1',
    name: 'Udit',
    email: 'udit@example.com',
    role: 'admin',
    password: 'secret',
    avatar: { url: 'https://example.com/avatar.png' },
    isEmailVerified: true
  }

  assert.deepEqual(publicUser(user), {
    id: 'user-1',
    name: 'Udit',
    email: 'udit@example.com',
    role: 'admin',
    avatar: { url: 'https://example.com/avatar.png' },
    isEmailVerified: true
  })
})
